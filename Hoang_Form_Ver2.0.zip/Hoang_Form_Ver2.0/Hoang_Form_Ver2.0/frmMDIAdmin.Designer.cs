﻿namespace Hoang_Form_Ver2._0
{
    partial class frmMDIAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDIAdmin));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.quayLạiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnQLCV = new System.Windows.Forms.Button();
            this.btnQLBP = new System.Windows.Forms.Button();
            this.btnQLNV = new System.Windows.Forms.Button();
            this.btnNV = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnQLLSP = new System.Windows.Forms.Button();
            this.btnQLH = new System.Windows.Forms.Button();
            this.btnQLSP = new System.Windows.Forms.Button();
            this.btnSP = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnTKND = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quayLạiToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(13, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(1920, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // quayLạiToolStripMenuItem
            // 
            this.quayLạiToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.quayLạiToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.quayLạiToolStripMenuItem.Image = global::Hoang_Form_Ver2._0.Properties.Resources.logout_icon;
            this.quayLạiToolStripMenuItem.Name = "quayLạiToolStripMenuItem";
            this.quayLạiToolStripMenuItem.Size = new System.Drawing.Size(128, 25);
            this.quayLạiToolStripMenuItem.Text = "Đăng Xuất";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.thoátToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.thoátToolStripMenuItem.Image = global::Hoang_Form_Ver2._0.Properties.Resources.tải_xuống1;
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(87, 25);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnQLCV);
            this.panel1.Controls.Add(this.btnQLBP);
            this.panel1.Controls.Add(this.btnQLNV);
            this.panel1.Controls.Add(this.btnNV);
            this.panel1.Location = new System.Drawing.Point(212, 215);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(304, 64);
            this.panel1.TabIndex = 1;
            // 
            // btnQLCV
            // 
            this.btnQLCV.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLCV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLCV.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLCV.Location = new System.Drawing.Point(0, 186);
            this.btnQLCV.Name = "btnQLCV";
            this.btnQLCV.Size = new System.Drawing.Size(304, 66);
            this.btnQLCV.TabIndex = 3;
            this.btnQLCV.Text = "Quản Lý Chức Vụ";
            this.btnQLCV.UseVisualStyleBackColor = false;
            // 
            // btnQLBP
            // 
            this.btnQLBP.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLBP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLBP.Location = new System.Drawing.Point(0, 125);
            this.btnQLBP.Name = "btnQLBP";
            this.btnQLBP.Size = new System.Drawing.Size(304, 66);
            this.btnQLBP.TabIndex = 2;
            this.btnQLBP.Text = "Quản Lý Bộ Phận";
            this.btnQLBP.UseVisualStyleBackColor = false;
            // 
            // btnQLNV
            // 
            this.btnQLNV.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLNV.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLNV.Location = new System.Drawing.Point(0, 62);
            this.btnQLNV.Name = "btnQLNV";
            this.btnQLNV.Size = new System.Drawing.Size(304, 66);
            this.btnQLNV.TabIndex = 1;
            this.btnQLNV.Text = "Quản Lý Nhân Viên";
            this.btnQLNV.UseVisualStyleBackColor = false;
            // 
            // btnNV
            // 
            this.btnNV.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNV.ForeColor = System.Drawing.Color.Chartreuse;
            this.btnNV.Location = new System.Drawing.Point(0, 0);
            this.btnNV.Name = "btnNV";
            this.btnNV.Size = new System.Drawing.Size(304, 64);
            this.btnNV.TabIndex = 0;
            this.btnNV.Text = "Nhân Viên";
            this.btnNV.UseVisualStyleBackColor = false;
            this.btnNV.MouseLeave += new System.EventHandler(this.btnNV_MouseLeave);
            this.btnNV.MouseHover += new System.EventHandler(this.btnNV_MouseHover);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnQLLSP);
            this.panel2.Controls.Add(this.btnQLH);
            this.panel2.Controls.Add(this.btnQLSP);
            this.panel2.Controls.Add(this.btnSP);
            this.panel2.Location = new System.Drawing.Point(596, 215);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(304, 64);
            this.panel2.TabIndex = 2;
            // 
            // btnQLLSP
            // 
            this.btnQLLSP.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLLSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLLSP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLLSP.Location = new System.Drawing.Point(0, 186);
            this.btnQLLSP.Name = "btnQLLSP";
            this.btnQLLSP.Size = new System.Drawing.Size(304, 66);
            this.btnQLLSP.TabIndex = 3;
            this.btnQLLSP.Text = "Quản Lý Loại SP";
            this.btnQLLSP.UseVisualStyleBackColor = false;
            // 
            // btnQLH
            // 
            this.btnQLH.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLH.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLH.Location = new System.Drawing.Point(0, 125);
            this.btnQLH.Name = "btnQLH";
            this.btnQLH.Size = new System.Drawing.Size(304, 66);
            this.btnQLH.TabIndex = 2;
            this.btnQLH.Text = "Quản Lý Hãng";
            this.btnQLH.UseVisualStyleBackColor = false;
            // 
            // btnQLSP
            // 
            this.btnQLSP.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnQLSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQLSP.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnQLSP.Location = new System.Drawing.Point(0, 62);
            this.btnQLSP.Name = "btnQLSP";
            this.btnQLSP.Size = new System.Drawing.Size(304, 66);
            this.btnQLSP.TabIndex = 1;
            this.btnQLSP.Text = "Quản Lý Sản Phẩm";
            this.btnQLSP.UseVisualStyleBackColor = false;
            // 
            // btnSP
            // 
            this.btnSP.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnSP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSP.ForeColor = System.Drawing.Color.Chartreuse;
            this.btnSP.Location = new System.Drawing.Point(0, 0);
            this.btnSP.Name = "btnSP";
            this.btnSP.Size = new System.Drawing.Size(304, 64);
            this.btnSP.TabIndex = 0;
            this.btnSP.Text = "Sản Phẩm";
            this.btnSP.UseVisualStyleBackColor = false;
            this.btnSP.MouseLeave += new System.EventHandler(this.btnSP_MouseLeave);
            this.btnSP.MouseHover += new System.EventHandler(this.btnSP_MouseHover);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnTKND);
            this.panel3.Location = new System.Drawing.Point(1005, 215);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(344, 64);
            this.panel3.TabIndex = 4;
            // 
            // btnTKND
            // 
            this.btnTKND.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnTKND.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTKND.ForeColor = System.Drawing.Color.Chartreuse;
            this.btnTKND.Location = new System.Drawing.Point(0, 0);
            this.btnTKND.Name = "btnTKND";
            this.btnTKND.Size = new System.Drawing.Size(344, 64);
            this.btnTKND.TabIndex = 0;
            this.btnTKND.Text = "Tài Khoản Người Dùng";
            this.btnTKND.UseVisualStyleBackColor = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 5;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 5;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // frmMDIAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Hoang_Form_Ver2._0.Properties.Resources._65369777_admin_gold_text_on_black_background_3d_rendered_royalty_free_stock_picture_this_image_can_be_used_fo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1920, 1051);
            this.ControlBox = false;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmMDIAdmin";
            this.Text = "Quản Lý Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMDIAdmin_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quayLạiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnQLCV;
        private System.Windows.Forms.Button btnQLBP;
        private System.Windows.Forms.Button btnQLNV;
        private System.Windows.Forms.Button btnNV;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnQLLSP;
        private System.Windows.Forms.Button btnQLH;
        private System.Windows.Forms.Button btnQLSP;
        private System.Windows.Forms.Button btnSP;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnTKND;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}