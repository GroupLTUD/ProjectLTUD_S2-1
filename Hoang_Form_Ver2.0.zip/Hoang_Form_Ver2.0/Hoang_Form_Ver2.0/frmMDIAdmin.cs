﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hoang_Form_Ver2._0
{
    public partial class frmMDIAdmin : Form
    {
        public frmMDIAdmin()
        {
            InitializeComponent();
        }


        //Xu ly drownList trong Button 
        int t1 = 49;
        int t2 = 49;

        private void btnNV_MouseHover(object sender, EventArgs e)
        {
            //this.panel1.Size = new Size(this.panel1.Size.Width, t3);
            this.panel2.Size = new Size(this.panel2.Size.Width, t2);
            timer1.Start();
        }
        private void btnNV_MouseLeave(object sender, EventArgs e)
        {
            timer1.Stop();
            t1 = 49;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (t1 > 252)
            {
                timer1.Stop();
            }
            else
            {
                this.panel1.Size = new Size(this.panel1.Size.Width, t1);
                t1 += 4;
            }
        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            if (t2 > 252)
            {
                timer2.Stop(); 
            }
            else
            {
                this.panel2.Size = new Size(this.panel2.Size.Width, t2);
                t2 += 4;
            }
        }
        private void btnSP_MouseHover(object sender, EventArgs e)
        {
            this.panel1.Size = new Size(this.panel1.Size.Width, t1);
            timer2.Start();
        }

        private void btnSP_MouseLeave(object sender, EventArgs e)
        {
            timer2.Stop();
            t2 = 49;
        }


        //xu ly thoat form
        private void frmMDIAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát chương trình không ? ", "Thoát ", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (r != DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }





    }
}
